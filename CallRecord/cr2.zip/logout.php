<?php
include('includes/config.php');
$model->logout();

?>